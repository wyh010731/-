#ifndef _HW_KEY_H
#define _HW_KEY_H

#include "main.h"
#include "stm32f1xx_hal.h"
//#include "stm32f1xx_hal_gpio.h"

#define MK_COL0_LOW 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET)
#define MK_COL1_LOW 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET)
#define MK_COL2_LOW 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET)
#define MK_COL3_LOW 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET)

#define MK_COL0_HIGH 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET)
#define MK_COL1_HIGH	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET)
#define MK_COL2_HIGH 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET)
#define MK_COL3_HIGH 	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET)

typedef struct Matrix_Button
{
	unsigned char (*MB_KEY_Scan)(void);
	void (*MB_KEY_Funcation)(void);
}MatrixButton_Struct;

extern MatrixButton_Struct MB_MatrixButton;



#endif  /* _HW_KEY_H */
