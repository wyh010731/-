#include "HW_KEY.h"
#include <stdio.h>
#include "OLED.h"
#include "key.h"

static unsigned char MB_KEY_RowScan(void);
static unsigned char MB_KEY_Scan(void);
static void MB_KEY_Funcation(void);
extern void LED_open(int i);
MatrixButton_Struct MB_MatrixButton =
{
	MB_KEY_Scan,
	MB_KEY_Funcation
};

uint8_t Key_Row[1] = {0xFF}; 

static unsigned char MB_KEY_RowScan(void)
{
	// 读行扫描状态
	Key_Row[0] = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0)<<3;
	Key_Row[0] = Key_Row[0] | (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1)<<2);
	Key_Row[0] = Key_Row[0] | (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2)<<1);
	Key_Row[0] = Key_Row[0] | (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3));	
	

	if(Key_Row[0] != 0x0f)
	{
		// 消抖
		HAL_Delay(10);
		if(Key_Row[0] != 0x0f)
		{
			//printf("Key_Row_DATA = 0x%x\r\n",Key_Row[0]);
			switch(Key_Row[0])
			{
				case 0x07: 							
					return 1;
				case 0x0b:							
					return 2;
				case 0x0d:							
					return 3;
				case 0x0e:							
					return 4;
			}
		}
		else 
			return 0;                 
	}
	else 
		return 0;  								
}


static unsigned char MB_KEY_Scan(void)
{
	unsigned char Key_Num = 0;         
	unsigned char Key_RowResault = 0;  
	
	
	MK_COL0_LOW;  
	if((Key_RowResault = MB_KEY_RowScan()) != 0)
	{
		while(MB_KEY_RowScan() != 0); // 消抖
		Key_Num = 0 + Key_RowResault;
	}
	MK_COL0_HIGH;
	
	
	MK_COL1_LOW;
	if((Key_RowResault = MB_KEY_RowScan()) != 0)
	{
 		while(MB_KEY_RowScan() != 0); // 消抖
		Key_Num = 4 + Key_RowResault;
	}
	MK_COL1_HIGH;
	
	
	MK_COL2_LOW;
	if((Key_RowResault = MB_KEY_RowScan()) != 0)
	{
		while(MB_KEY_RowScan() != 0); // 消抖
		Key_Num = 8 + Key_RowResault;
	}
	MK_COL2_HIGH;
	
	
	MK_COL3_LOW;
	if((Key_RowResault = MB_KEY_RowScan()) != 0)
	{
		while(MB_KEY_RowScan() != 0); // 消抖
		Key_Num = 12 + Key_RowResault;
	}
	MK_COL3_HIGH;
	
	
	return Key_Num;
}

static void MB_KEY_Funcation(void)
{
	unsigned char Key_Code,f=0;
	Key_Code = MB_KEY_Scan();
	switch(Key_Code)
	{
		case 1:
			MK_KeyUserCode_1();
			//printf("1\r\n");
		break;
		
		case 2:
			MK_KeyUserCode_5();
			//printf("2\r\n");
		break;
		
		case 3:
			MK_KeyUserCode_9();
			//printf("3\r\n");
		break;
		
		case 4:
			MK_KeyUserCode_identify();
			//printf("4\r\n");
		break;
		
		case 5:
			MK_KeyUserCode_2();
			//printf("5\r\n");
		break;
		
		case 6:
			MK_KeyUserCode_6();
			//printf("6\r\n");
		break;
		
		case 7:
			MK_KeyUserCode_10();
			//printf("7\r\n");
		break;
		
		case 8:
			MK_KeyUserCode_cancel();
			//printf("8\r\n");
		break;
		
		case 9:
			MK_KeyUserCode_3();
			//printf("9\r\n");
		break;
		
		case 10:
			MK_KeyUserCode_7();
			//printf("10\r\n");
		break;
		
		case 11:
			MK_KeyUserCode_11();
			//printf("11\r\n");
		break;
		case 12:
			LED_open(1);
		//printf("12\r\n");
		break;
		
		case 13:
			MK_KeyUserCode_4();
			//printf("13\r\n");
		break;
		
		case 14:
			MK_KeyUserCode_8();
			//printf("14\r\n");
		break;
		
		case 15:
			MK_KeyUserCode_12();
			//printf("15\r\n");
		break;
		
		case 16:
			printf("16\r\n");
		break;
	}
}
